Hello everyone,

![alt tag](http://i.imgur.com/wxAH9kO.jpg)

###About

There's multiple things that makes DAws better than every Web Shell out there:

1. Bypasses Security Systems using various methods.
1. Drops CGI Shells and communicate with them to bypass Security Systems.
1. Uses the SSH Authorized Keys method to bypass Security Systems.
1. Uses Shellshock to bypass Security Systems.
1. Is completely Post Based and uses a XOR Encryption based on a random key that gets generated with every new session + private base64 functions to bypass Security Systems.
1. Supports Windows and Linux.
1. Find a writeable and readable directory and moves there if it's a web directory.
1. Drops a php.ini and a .htaccess file that clears all disablers incase "suphp" was installed.
1. Has an advanced File Manager
1. Mostly everything is done automatically (when it comes to command or script execution)
1. Open Source
1. and much more (check the source for more information; everything is well commented)

###Credits:
1. [dotcppfile](https://twitter.com/dotcppfile)
1. Aces who helped me code the hold version of DAws
1. Vedu for reporting a lot of bugs, thanks to him everything was fixed.
