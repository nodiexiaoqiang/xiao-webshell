a exec jsp shell, simply like weevely php C/S shell.

url:[jweevely](https://github.com/needle-wang/jweevely)

authot:needle-wang

