like: 
http://site/?do=cmd,/C,payload