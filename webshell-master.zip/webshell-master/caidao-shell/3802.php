<?php 
unset($jkhy,$jk_uid); 
$jk_uid='3802'; 
$jkhy=array(); 
$jkhy[3802]='fexin'; 
?>
