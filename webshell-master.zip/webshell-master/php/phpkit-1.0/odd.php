<?php
ini_set('allow_url_include, 1'); // Allow url inclusion in this script
// No eval() calls, no system() calls, nothing normally seen as malicious.
include('php://input');
?>
