like this:  

www.site.com/shell.asp?x=a